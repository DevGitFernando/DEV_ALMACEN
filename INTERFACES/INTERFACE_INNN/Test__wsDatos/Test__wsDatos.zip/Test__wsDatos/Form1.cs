﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using Test__wsDatos.wsIN3Sigma; 

namespace Test__wsDatos
{
    public partial class Form1 : Form
    {
        //clsListView lst;
        wsIN3Sigma.wsSigma datosSigma;
        string sDatosRecibidos = "";

        public Form1()
        {
            InitializeComponent();

            radioButton1.Checked = true;

            ////lst = new clsListView(listViewDatos);
            ////lst.Limpiar();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            ////lst.Limpiar();
            txtDatosRecibidos.Text = "";
        }

        private void wsSigma_obtenerMedicamentos_porPacienteCompleted(object sender, obtenerMedicamentos_porPacienteCompletedEventArgs e)
        {
            //sDatosRecibidos = e.Result;

            //txtDatosRecibidos.Text = sDatosRecibidos;

            //MessageBox.Show("Proceso terminado con correctamente.");
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            bool bRegresa = false;
            sDatosRecibidos = "";
            txtDatosRecibidos.Text = ""; 

            try
            {
                wsSigma.Url = txtUrl.Text.Trim();

                //sDatosRecibidos = wsSigma.obtenerMedicamentos_porPaciente(dtpFechaInicial.Value, dtpFechaFinal.Value);

                MessageBox.Show(wsSigma.obtenerMedicamentos_porPaciente(dtpFechaInicial.Value, dtpFechaFinal.Value), "Respuesta");
                //sDatosRecibidos = 
                    //wsSigma.obtenerMedicamentos_porPacienteAsync(dtpFechaInicial.Value, dtpFechaFinal.Value, bRegresa);
                //MessageBox.Show("Proceso terminado con correctamente.");
            }
            catch (Exception ex)
            {
                sDatosRecibidos = ex.Message;
                MessageBox.Show("Proceso terminado con errores.");
            }

            txtDatosRecibidos.Text = sDatosRecibidos; 

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            dtpFechaInicial.CustomFormat = "yyyy/MM/dd";
            dtpFechaFinal.CustomFormat = dtpFechaInicial.CustomFormat;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            dtpFechaInicial.CustomFormat = "MM/dd/yyyy";
            dtpFechaFinal.CustomFormat = dtpFechaInicial.CustomFormat;
        }
    }
}
